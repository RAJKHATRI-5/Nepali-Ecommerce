# Nepali E-Commerce Platform with Haptic Feedback
**BSc Computer Science Final Year Project - Milestone 5**

## Student Information
- **Name**: Raj Khatri
- **Student Number**: 2228573
- **Project**: E-Commerce Platform for Nepali Products with Haptic Feedback Integration
- **Academic Question**: How can haptic feedback and touch-based HCI principles enhance the online shopping experience for diaspora communities purchasing culturally significant products?

## Quick Start
1. Open `index.html` in a web browser
2. For haptic testing, use a physical Android device with Chrome
3. For audio testing, enable audio in Settings page
4. Use Chrome DevTools device emulator for responsive testing

## Project Structure
```
nepali-ecommerce/
├── index.html          - Main product page with search and filters
├── cart.html           - Shopping cart with checkout
├── settings.html       - User preferences (haptic/audio toggles)
├── css/
│   └── style.css       - All styling (mobile-first responsive)
├── js/
│   ├── products.js     - Product data, filtering, search, detail modal
│   ├── cart.js         - Cart functionality, checkout workflow, order confirmation
│   ├── haptics.js      - Web Vibration API wrapper with debouncing
│   ├── audio.js        - Web Audio API feedback (iOS/desktop fallback)
│   └── settings.js     - User preference management
└── images/
    └── products/       - Product images
```

## Features (Milestone 5)
- **Product Catalogue**: 10 authentic Nepali products with cultural context
- **Search & Filter**: Real-time search with category filtering
- **Product Details**: Modal with cultural significance and artisan information
- **Shopping Cart**: Add, remove, update quantities with localStorage persistence
- **Checkout Workflow**: Form with delivery info, payment options, order confirmation
- **Haptic Feedback**: Web Vibration API with 8 distinct patterns, debouncing
- **Audio Feedback**: Web Audio API synthesised sounds as alternative/complement
- **Settings Page**: Toggle haptic/audio feedback, test functionality, clear data
- **Responsive Design**: Mobile-first CSS with breakpoints for phone/tablet/desktop
- **Accessibility**: Skip navigation, ARIA labels, keyboard navigation, semantic HTML

## Technologies
- HTML5 (semantic elements)
- CSS3 (Grid, Flexbox, CSS Variables, media queries)
- Vanilla JavaScript (ES6+)
- Web Vibration API
- Web Audio API
- Web Storage API (localStorage)

## Browser Support
- **Full (with haptics)**: Chrome Android, Firefox Android, Samsung Internet
- **Partial (no haptics)**: Safari iOS, Desktop browsers (visual + audio feedback)

## Changes from Milestone 4
- Added product search functionality with debounced input
- Added category filtering with pill-button UI
- Added product detail modal with cultural context and artisan info
- Added audio feedback module using Web Audio API
- Added complete checkout workflow with form validation
- Added order confirmation with generated order number
- Added settings page for haptic/audio preference management
- Added haptic debouncing (300ms minimum interval)
- Enhanced accessibility (skip links, ARIA attributes, keyboard nav)
- Enhanced product data with origin and artisan information
- Improved notification system with type-based styling
- Refined responsive design for all screen sizes
